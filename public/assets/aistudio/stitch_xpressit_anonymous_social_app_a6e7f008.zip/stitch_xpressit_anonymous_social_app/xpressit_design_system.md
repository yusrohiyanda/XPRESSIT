---
name: "XPRESSIT"
description: "Anonymous social experience-sharing platform design system built with deep purple, radiant lavender, and soft pink accents."
---

## Overview

XPRESSIT is an anonymous social experience-sharing platform empowering people to express personal thoughts, life secrets, confessions, voice notes, and stories without exposing their identity. The design identity is modern, minimalistic, youthful, and premium, prioritizing privacy, comfort, and psychological safety.

The visual language pairs deep, immersive violet and obsidian dark tones with luminous lavender highlights and delicate soft-pink accents. Smooth rounded corners, refined elevation with subtle ambient violet glows, clear hierarchy, and empathetic micro-copy create a welcoming sanctuary for authentic human expression.

## Colors

The brand color palette uses deep purple `#7045C6` as its core anchor, paired with soft lavender `#A78BFA` and luminous soft pink accent `#E879F9`. Both light and dark modes provide high-contrast, WCAG AA compliant surfaces.

- **Primary:** Deep violet `#7045C6` embodying introspection, safety, and modern social craft.
- **Secondary:** Radiant lavender `#A78BFA` representing gentle empathy and connection.
- **Accent:** Soft luminous pink `#E879F9` providing vibrant micro-highlights, live badges, and recording pulses.
- **Status & Feedback:** Semantic states for success, warning, and report/destructive actions.

```yaml
colors:
  primary: "#7045C6"
  primary-light: "#8B5CF6"
  secondary: "#A78BFA"
  accent: "#E879F9"
  accent-soft: "#FDF2F8"
  success: "#10B981"
  warning: "#F59E0B"
  danger: "#EF4444"
  light:
    primary: "#7045C6"
    on-primary: "#FFFFFF"
    primary-container: "#EDE9FE"
    on-primary-container: "#4C1D95"
    surface: "#F8F7FC"
    on-surface: "#1F1D2B"
    surface-card: "#FFFFFF"
    on-surface-card: "#1F1D2B"
    surface-card-subtle: "#F3F0FA"
    outline: "#E2DCF0"
    outline-subtle: "#EDE8F5"
    text-muted: "#6B7280"
  dark:
    primary: "#A78BFA"
    on-primary: "#171522"
    primary-container: "#2D2644"
    on-primary-container: "#DDD6FE"
    surface: "#171522"
    on-surface: "#F3F0FA"
    surface-card: "#262333"
    on-surface-card: "#F3F0FA"
    surface-card-subtle: "#1F1D2B"
    outline: "#3A354D"
    outline-subtle: "#2A2739"
    text-muted: "#9CA3AF"
```

## Typography

XPRESSIT employs **Plus Jakarta Sans** for expressive, modern headlines and **Inter** for ultra-legible social feeds, body copy, and UI controls.

```yaml
typography:
  display-lg:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 36px
    fontWeight: 800
    lineHeight: 44px
    letterSpacing: -0.75px
  display-lg-mobile:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 28px
    fontWeight: 800
    lineHeight: 36px
    letterSpacing: -0.5px
  headline-lg:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 32px
    fontWeight: 700
    lineHeight: 40px
    letterSpacing: -0.5px
  headline-lg-mobile:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 24px
    fontWeight: 700
    lineHeight: 32px
    letterSpacing: -0.25px
  headline-md:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 20px
    fontWeight: 700
    lineHeight: 28px
    letterSpacing: -0.25px
  headline-sm:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 18px
    fontWeight: 600
    lineHeight: 26px
  body-lg:
    fontFamily: "Inter"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 24px
  body-md:
    fontFamily: "Inter"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 20px
  body-sm:
    fontFamily: "Inter"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 18px
  label-lg:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 15px
    fontWeight: 600
    lineHeight: 20px
  label-md:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 13px
    fontWeight: 600
    lineHeight: 18px
  label-sm:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 11px
    fontWeight: 600
    lineHeight: 16px
    letterSpacing: 0.25px
```

## Layout & Spacing

Mobile-first single-column layout strictly adhering to a 4px/8px rhythm. Page padding is 16px to 20px on mobile with 12px to 16px card gaps.

```yaml
spacing:
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 12px
  gutter-lg: 16px
  gutter-xl: 24px
  section: 32px
  page-margin: 16px
```

## Elevation & Depth

Surfaces use gentle, tinted ambient shadows rather than harsh drop shadows. In dark mode, layered container tokens (`surface` vs `surface-card`) provide depth with subtle `#3A354D` outline borders. In light mode, crisp `#E2DCF0` borders and soft ambient blur give cards a floating, tactile appearance.

## Shapes

Shapes feature generous, friendly corner radii with pill-shaped badges, rounded buttons, and 20px-24px rounded card surfaces.

```yaml
rounded:
  sm: 6px
  DEFAULT: 12px
  md: 16px
  lg: 20px
  xl: 24px
  full: 9999px
```

## Motion & Micro-interaction

Interactions feel immediate, responsive, and reassuring:
- Audio waveforms animate dynamically during recording and playback.
- Tab bar transitions utilize subtle scale and lavender pill highlights.
- Copy actions provide immediate haptic/visual confirmation tags.

```yaml
motion:
  state-change:
    duration: 150ms
    delay: 0ms
    timingFunction: ease-out
  surface-enter:
    duration: 250ms
    delay: 0ms
    timingFunction: cubic-bezier(0.16, 1, 0.3, 1)
  surface-exit:
    duration: 150ms
    delay: 0ms
    timingFunction: cubic-bezier(0.4, 0, 1, 1)
```

## Voice & Content Strategy

The voice of XPRESSIT is safe, empathetic, non-judgmental, and clear:
- Anonymous usernames emphasize persona rather than identity: "Anonymous Soul", "Secret Voice", "Wandering Poet", "Starlit Mind".
- Action buttons are actionable and clear: "Publish Anonymously", "Generate Passphrase", "Copy Passphrase", "Start Recording".
- Safety reminders are proactive: "Voice recordings may carry identifiable vocal traits", "Metadata and location stripped automatically".

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Button** → `@components/button.html`: `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html`: `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
- **Input Field** → `@components/input-field.html`: `input-field-text`, `input-field-icon`
- **Modal** → `@components/modal.html`: `modal-standard`, `modal-alert`, `modal-drawer`
- **Tabs** → `@components/tabs.html`: `tabs-horizontal`, `tabs-with-icon`
